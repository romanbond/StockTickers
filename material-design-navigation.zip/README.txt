A Pen created at CodePen.io. You can find this one at http://codepen.io/Lewitje/pen/tyGdf.

 The page slides to reveal a clean, simple navigation