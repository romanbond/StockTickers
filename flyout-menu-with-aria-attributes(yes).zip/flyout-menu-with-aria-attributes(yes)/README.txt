A Pen created at CodePen.io. You can find this one at http://codepen.io/hexagoncircle/pen/ONXxrW.

 Project for adding toggle buttons, ARIA attributes, and converting a basic navigation list to a flyout menu with JS.