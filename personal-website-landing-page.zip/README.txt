A Pen created at CodePen.io. You can find this one at http://codepen.io/jakamusic/pen/LNmbMd.

 Modern Personal Website Landing page with full screen background image and some fancy blur effects, cool fonts and logo display.