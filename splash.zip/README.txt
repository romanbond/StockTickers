A Pen created at CodePen.io. You can find this one at http://codepen.io/winkerVSbecks/pen/oLmqQo.

 Recreated https://dribbble.com/shots/2896850-Animated-DropSplash-Logo-Posibility with React and SVG