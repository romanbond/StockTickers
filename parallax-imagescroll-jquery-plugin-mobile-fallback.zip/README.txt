A Pen created at CodePen.io. You can find this one at http://codepen.io/pederan/pen/Hheuy.

 Check at the documentation on Github: https://github.com/pederan/Parallax-ImageScroll