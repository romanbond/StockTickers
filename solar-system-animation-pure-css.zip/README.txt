A Pen created at CodePen.io. You can find this one at http://codepen.io/kowlor/pen/ZYYQoy.

 Here is a true time scaled solar-system, which means that every objects have a time relative to an Earth year.