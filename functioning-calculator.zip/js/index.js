(function($) {

	var first, operator, second, result;

	first = 0;
	second = 0;

	var different_ops = ['c', '+ / -', '%', '√', ',', '=', 'π'];
	var nums = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

	var picker = $('.picker');
	var c_button = $('.picker > div');
	var latest_entered = $('.l_entered');
	var newest_entered = $('.n_entered');
	var operator_p = $('.operator');
	var current = $('.current');
	var buttons = $('.buttons');
	var button = $('.buttons > div');

	function isNumeric(num) {
		return !isNaN(num);
	}

	function arrayContains(needle, arrhaystack) {
		return (arrhaystack.indexOf(needle) > -1);
	}

	function precise_round(num, decimals) {
		return Math.round(num * Math.pow(10, decimals)) / Math.pow(10, decimals);
	}

	button.on('mousedown', function() {
		var $this = jQuery(this);
		$this.addClass('pressed');
		setTimeout(function() {
			$this.removeClass('pressed');
		}, 400);
	});

	button.on('mouseup', function() {
		$(this).removeClass('pressed');
	});

	button.on('click', function() {
		symbol = $(this).children().text();

		if (symbol === "c") {
			first = "";
			second = "";
			current.children().text('0');
			latest_entered.text('');
			newest_entered.text('');
			operator_p.text('');
			operator = "";
		}

		if (symbol === "√") {
			if (current.children().text() === "0") {
				current.children().text('√');
			} else {
				first = current.children().text();
				first = "√".concat(first);
				current.children().text(first);
			}
			if (operator) {
				second = current.children().text();
			} else {
				first = current.children().text();
			}
		}

		if (isNumeric(symbol) && first.length < 10 && !operator && first && !arrayContains(symbol, different_ops)) {
			first = first.concat(symbol);
			current.children().text(first);
		}

		if (isNumeric(symbol) && !second && !first && !arrayContains(symbol, different_ops)) {
			first = symbol;
			current.children().text(first);
			console.log('bloop');
		}

		if (!isNumeric(symbol) && symbol !== "=" && first && !operator && !arrayContains(symbol, different_ops)) {
			operator = symbol;
			latest_entered.text(first);
			operator_p.text(operator);
			current.children().text('0');
		}

		if (isNumeric(symbol) && second.length < 10 && second && !arrayContains(symbol, different_ops)) {
			second = second.concat(symbol);
			current.children().text(second);
		}

		if (isNumeric(symbol) && !second && operator && !arrayContains(symbol, different_ops)) {
			second = symbol;
			current.children().text(second);
		}

		if (second && symbol === "=") {
			if (first.toString().indexOf("√") > -1) {
				var number = first.substr(1);
				first = Math.sqrt(number);
			}
			if (second.toString().indexOf("√") > -1) {
				var number = second.substr(1);
				second = precise_round(Math.sqrt(number), 5);
			}
			var firstInt = parseFloat(first);
			var secondInt = parseFloat(second);
			switch (operator) {
				case "+":
					result = firstInt + secondInt;
					break;
				case "-":
					result = firstInt - secondInt;
					break;
				case "x":
					result = firstInt * secondInt;
					break;
				case "/":
					result = firstInt / secondInt;
					break;
				default:
					result = firstInt * secondInt;
					break;
			}

			if (precise_round(result, 1).toString().length < 10) {
				var fin_result = precise_round(result, 5);
			} else {
				var fin_result = result.toExponential(3);
			}

			newest_entered.text(second);
			current.children().text(fin_result);
		}

		if (symbol === "=" && first.indexOf("√") > -1) {
			result = Math.sqrt(first.substr(1));
			var fin_result = precise_round(result, 4);
			current.children().text(fin_result);
			first = fin_result;
			operator = "";
			second = "";
		}

		if (symbol === "+ / -" && current.children().text().charAt(0) !== '-') {
			current.children().text("-" + current.children().text());
			if (operator) {
				second = current.children().text();
			} else {
				first = current.children().text();
			}

			var just_added_neg = true;
			setTimeout(function() {
				just_added_neg = false;
			}, 1)
		}

		if (symbol === "+ / -" && current.children().text().charAt(0) == '-' && current.children().text().charAt(1) === '√') {
			var number = current.children().text().substr(2);
			current.children().text("-" + precise_round(Math.sqrt(number), 5));
			if (operator) {
				second = current.children().text();
			} else {
				first = current.children().text();
			}
		}

		if (symbol === "+ / -" && current.children().text().charAt(0) === '-' && !just_added_neg) {
			current.children().text(current.children().text().substr(1));
			if (operator) {
				second = current.children().text();
			} else {
				first = current.children().text();
			}
		}

		if (symbol === "π") {
			if (current.children().text().charAt(0) === "√") {
				current.children().text('√3,14159');
			} else if (arrayContains(current.children().text(), nums)) {
				current.children().text(precise_round(current.children().text() * 3.14159, 5));
			} else {
				current.children().text(precise_round(Math.PI, 7));
			}
			if (operator) {
				second = current.children().text().replace(",", ".");
			} else {
				first = current.children().text().replace(",", ".");
			}
		}

		if (symbol === ',' && current.children().text().match(/./g).length <= 1) {
			current.children().text(current.children().text() + ".");
			if (operator) {
				second = current.children().text();
			} else {
				first = current.children().text();
			}
		}

		if (!isNumeric(symbol) && first && operator && second && !arrayContains(symbol, different_ops)) {
			latest_entered.text(current.children().text());
			operator_p.text(symbol);
			newest_entered.text('');
			current.children().text('0');
			first = latest_entered.text();
			operator = symbol;
			second = "";
		}

		console.log(first);
		console.log(operator);
		console.log(second);

	});

	$(window).on('keydown', function(event) {
		switch (event.which) {
			case 8:
				current.children().text(current.children().text().slice(0, -1));
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 48:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '0');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 49:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '1');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 50:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '2');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 51:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '3');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 52:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '4');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 53:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '5');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 54:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '6');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 55:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '7');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 56:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '8');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 57:
				if (current.children().text() === "0") current.children().text('');
				if (current.children().text().length < 10) current.children().text(current.children().text() + '9');
				if (operator) {
					second = current.children().text();
				} else {
					first = current.children().text();
				}
				break;
			case 13:
				if (second) {
					var firstInt = parseFloat(first);
					var secondInt = parseFloat(second);
					switch (operator) {
						case "+":
							result = firstInt + secondInt;
							break;
						case "-":
							result = firstInt - secondInt;
							break;
						case "x":
							result = firstInt * secondInt;
							break;
						case "/":
							result = firstInt / secondInt;
							break;
						default:
							result = firstInt * secondInt;
							break;
					}

					if (precise_round(result, 1).toString().length < 10) {
						var fin_result = precise_round(result, 5);
					} else {
						var fin_result = result.toExponential(3);
					}

					newest_entered.text(second);
					current.children().text(fin_result);
				}
				break;
			case 27:
			case 67:
				first = "", second = "";
				current.children().text('0');
				latest_entered.text('');
				newest_entered.text('');
				operator_p.text('');
				operator = "";
				break;
		};
	});

	document.onkeypress = function(evt) {
		evt = evt || window.event;
		var charCode = evt.which || evt.keyCode;
		var charStr = String.fromCharCode(charCode);
		if (charStr == "-") {
			if (first && operator && second) {
				latest_entered.text(current.children().text());
				operator_p.text("-");
				newest_entered.text('');
				current.children().text('0');
				first = latest_entered.text();
				operator = "-";
				second = "";
			} else {
				operator = "-";
				latest_entered.text(first);
				operator_p.text(operator);
				current.children().text('0');
			}
		}
		if (charStr == "+" && first) {
			if (first && operator && second) {
				latest_entered.text(current.children().text());
				operator_p.text("+");
				newest_entered.text('');
				current.children().text('0');
				first = latest_entered.text();
				operator = "+";
				second = "";
			} else {
				operator = "+";
				latest_entered.text(first);
				operator_p.text(operator);
				current.children().text('0');
			}
		}
		if (charStr == "/") {
			if (first && operator && second) {
				latest_entered.text(current.children().text());
				operator_p.text("/");
				newest_entered.text('');
				current.children().text('0');
				first = latest_entered.text();
				operator = "/";
				second = "";
			} else {
				operator = "/";
				latest_entered.text(first);
				operator_p.text(operator);
				current.children().text('0');
			}
		}
		if (charStr == "x") {
			if (first && operator && second) {
				latest_entered.text(current.children().text());
				operator_p.text("x");
				newest_entered.text('');
				current.children().text('0');
				first = latest_entered.text();
				operator = "x";
				second = "";
			} else {
				operator = "x";
				latest_entered.text(first);
				operator_p.text(operator);
				current.children().text('0');
			}
		}
	};

	$(document).on('keydown', function(event) {
		if (event.keyCode == 8) {
			event.preventDefault();
		}
	});

})(jQuery);