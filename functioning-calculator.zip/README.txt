A Pen created at CodePen.io. You can find this one at http://codepen.io/Roemerdt/pen/YWRwoG.

 Design based on https://dribbble.com/shots/2311064-Calculator