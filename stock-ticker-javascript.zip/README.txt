A Pen created at CodePen.io. You can find this one at http://codepen.io/dustlilac/pen/xbOzXR.

 by Mikeldi Cesteros
forked from http://jsfiddle.net/chufol/Q3z9U/
more info on http://www.mandogroup.com/blog/2014/dynamic-stock-ticker-in-sharepoint/