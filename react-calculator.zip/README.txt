A Pen created at CodePen.io. You can find this one at http://codepen.io/tbremer/pen/wKpaWe.

 Calculator is an exercise in React, playing with custom data stores and PostCSS.

Click the `RECALL` button for a brief abstraction on a Flux store. The code for the store starts on `line 177`.

Works on mobile as well, though the UI is not as responsive as I would like. Any thoughts or suggestions would be great.