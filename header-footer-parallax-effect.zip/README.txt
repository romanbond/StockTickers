A Pen created at CodePen.io. You can find this one at http://codepen.io/hudsonmarinho/pen/FHGeK.

 - A small example of how to create a simple parallax.
- In the example we have a header size of the screen (window), that can be used as a slide.
- The size of the content is dynamic and fully customized.
- The size of the footer is define the [main.js](https://github.com/hudsonmarinho/header-and-footer-parallax-effect/blob/master/assets/stylesheets/main.css#L48) file.