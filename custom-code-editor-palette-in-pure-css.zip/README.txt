A Pen created at CodePen.io. You can find this one at http://codepen.io/Varo/pen/RPLmeP.

 A custom code editor palette in pure CSS!