var cmRule = document.getElementById('cm-rule'),
    inchRule = document.getElementById('in-rule'),
    mmDiam = document.getElementById('mm-diam'),
    inchDiam = document.getElementById('in-diam')

for(i=150;i--;){
  cmRule.innerHTML+='<div></div>'
}
for(i=(6*16);i--;){
  inchRule.innerHTML+='<div></div>'
}
for(i=0;i<20;i++){
  mmDiam.innerHTML+='<div style=width:'+i/10+'cm;height:'+i/10+'cm></div>'
}
for(i=0;i<24;i++){
  inchDiam.innerHTML+='<div style=width:'+i/16+'in;height:'+i/16+'in></div>'
}