A Pen created at CodePen.io. You can find this one at http://codepen.io/rikschennink/pen/zvcgx.

 Realtime blurring like in iOS 7, uses CSS blur, so your browser better support it.