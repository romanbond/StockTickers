A Pen created at CodePen.io. You can find this one at http://codepen.io/andytran/pen/BNjymy.

 This is a demo of Justin Kwak's Article News Card that he posted on Dribbble.

Shot Link:
https://dribbble.com/shots/2001637-Article-News-Card-UI