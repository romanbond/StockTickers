A Pen created at CodePen.io. You can find this one at http://codepen.io/oknoblich/pen/iexyj.

 this is a modification of http://thecodeplayer.com/walkthrough/perspective-mockups-css3-3d-transforms