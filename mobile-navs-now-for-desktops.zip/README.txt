A Pen created at CodePen.io. You can find this one at http://codepen.io/StephenScaff/pen/zvaCi.

 Offcanvas navs and what nots are making their way to desktops as of late. Here's a nav pattern that drops and overlay then the links animate down a touch. Similar to Teehan+Lax's nav, but the panel fades in rather than slides down, there's only 4 lines of Jquery (coulda been 3 really), and a sorta shit load of css.

Updated - to close on background.

Hamburger icon rotates to X too.