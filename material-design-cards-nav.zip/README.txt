A Pen created at CodePen.io. You can find this one at http://codepen.io/Lewitje/pen/oXvYEd.

 This is a really simple app that has a navigation and some cards.