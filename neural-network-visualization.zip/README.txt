A Pen created at CodePen.io. You can find this one at http://codepen.io/towc/pen/wGjXGY.

 That's definitely a wrong rapresentation of a NN, but it looks cool :D

Click to generate a new structure