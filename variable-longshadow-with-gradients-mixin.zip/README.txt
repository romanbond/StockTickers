A Pen created at CodePen.io. You can find this one at http://codepen.io/dariocorsi/pen/jqxERJ.

 "Your scientists were so preoccupied with whether or not they could, they didn’t stop to think if they should."

This doesn't need to exist. But now you can define long shadows with different colors and spreads with one Sass mixin.