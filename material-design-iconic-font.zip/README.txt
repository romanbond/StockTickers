A Pen created at CodePen.io. You can find this one at http://codepen.io/zavoloklom/pen/uqCsB.

 Based on: 
Material Design Icons by Google (https://github.com/google/material-design-icons)

Tested on Win8.1 with browsers: Chrome 37, Firefox 32, Opera 25, IE 11, Safari 5.1.7

More information on: http://zavoloklom.github.io/material-design-iconic-font/